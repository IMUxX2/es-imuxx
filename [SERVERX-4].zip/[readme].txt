[SERVERX-4]

PLAY FULL BRUTAL AS MUCH AS YOU CAN.
APPLY ALL HACKS.

ғᴏʀ ᴘᴜʙɢ GLOBAL.

PRE INSTALL 
NEEDED IN TERMUX.

pkg install git
 
pkg install toilet 

pkg install ruby 

pkg install python2  

pkg install wget 

pkg install neofetch

pkg install tsu

gem install lolcat

pkg install sl


EXTRACT ZIP then
run SETUP.sh

script move in download folder 

 
NOW MT MANAGER STEP 1ST IS OVER

OPEN TERMUX TYPE
tsu
ENTER
tsu -c ./X-4
ENTER

USERNAME :- X-YT
PASSWORD :- X-4


1) PUBG GLOBAL ANTIBAN

2) GET CONNECTION FROM SERVER...

3) START PUBG...

4) APPLY LOBBY MEMORY ANTIBAN. (SCRIPT CREDIT MISVAK HACK)

5) AFTER CHIKKEN DINNER SEND FEEDBACK FOR MORE ANTIBAN HACKS 
   SEND FEEDBACK HERE :- @IAMX_YT

PLAY BRUTALL...

ENJOY..


ALL CREDIT GOES TO @IAMX_YT
SUPPORT @IAM_X_YT








